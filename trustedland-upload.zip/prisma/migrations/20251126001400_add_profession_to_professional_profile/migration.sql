-- AlterTable
ALTER TABLE "ProfessionalProfile" ADD COLUMN "profession" TEXT;
