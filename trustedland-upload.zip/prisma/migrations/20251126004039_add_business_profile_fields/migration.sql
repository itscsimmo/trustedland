-- AlterTable
ALTER TABLE "ProfessionalProfile" ADD COLUMN "accreditations" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "awards" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "companyRegNo" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "establishedYear" INTEGER;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "insuranceLevel" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "numEmployees" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "servicesOffered" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "turnoverRange" TEXT;
ALTER TABLE "ProfessionalProfile" ADD COLUMN "website" TEXT;
